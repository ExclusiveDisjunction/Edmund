//
//  CurrentBalancesWidget.swift
//  Edmund
//
//  Created by Hollan Sellars on 7/6/25.
//

import SwiftUI
import WidgetKit
import EdmundWidgetCore
